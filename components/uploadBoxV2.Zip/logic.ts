export const uploadBoxLogic = String.raw`
const fileInput = document.getElementById('file-input');
const zone = document.getElementById('upload-zone');
const previewImg = document.getElementById('preview-img');
const placeholder = document.getElementById('placeholder');
const crownLine = document.getElementById('crown-line');
const chinLine = document.getElementById('chin-line');
const detectBtn = document.getElementById('detect-btn');
const createBtn = document.getElementById('create-btn');
const newPhotoBtn = document.getElementById('new-photo-btn');
const downloadBtn = document.getElementById('download-btn');
const canvas = document.getElementById('result-canvas');
const statusEl = document.getElementById('status');
const resultPanel = document.getElementById('resultPanel');
const uploadTips = document.getElementById('uploadTips');
const validationCard = document.getElementById('validation-card');
const checkFace = document.getElementById('check-face');
const checkEyes = document.getElementById('check-eyes');
const checkMouth = document.getElementById('check-mouth');
const checkGlasses = document.getElementById('check-glasses');
const checkPosition = document.getElementById('check-position');
const validationFinal = document.getElementById('validation-final');
const ctx = canvas.getContext('2d');

const TARGET = 600;
const PHOTO_CM = 5.08;
const HEAD_CM = 2.8;
const TARGET_HEAD_PX = TARGET * (HEAD_CM / PHOTO_CM);
const TOP_MARGIN_CM = 0.55;
const TOP_MARGIN_PX = TARGET * (TOP_MARGIN_CM / PHOTO_CM);

let uploadedFile = null;
let uploadedImg = null;
let bgRemovedImg = null;
let resultUrl = null;
let faceTiltAngle = 0;
let photoValidationPassed = false;
let draggingLine = null;
let faceMesh = null;

function setCreateEnabled(enabled) {
  photoValidationPassed = !!enabled;
  if (!createBtn) return;
  createBtn.disabled = !enabled;
  createBtn.style.opacity = enabled ? '1' : '0.45';
  createBtn.style.cursor = enabled ? 'pointer' : 'not-allowed';
}

function setDownloadEnabled(enabled) {
  if (!downloadBtn) return;
  downloadBtn.disabled = !enabled;
  downloadBtn.style.opacity = enabled ? '1' : '0.55';
  downloadBtn.style.cursor = enabled ? 'pointer' : 'not-allowed';
}

function resetValidationUI() {
  if (validationCard) {
    validationCard.style.display = 'none';
    validationCard.className = 'validation-card';
  }
  if (checkFace) checkFace.textContent = '';
  if (checkEyes) checkEyes.textContent = '';
  if (checkMouth) checkMouth.textContent = '';
  if (checkGlasses) checkGlasses.textContent = '';
  if (checkPosition) checkPosition.textContent = '';
  if (validationFinal) validationFinal.textContent = '';
}

function showValidationError(message) {
  if (validationCard) {
    validationCard.style.display = 'block';
    validationCard.className = 'validation-card validation-error';
  }
  if (validationFinal) validationFinal.innerHTML = message;
  statusEl.innerHTML = message;
  setCreateEnabled(false);
}

function showValidationReady() {
  if (validationCard) {
    validationCard.style.display = 'block';
    validationCard.className = 'validation-card';
  }
  if (validationFinal) validationFinal.textContent = '✅ Ready to Create Photo';
  statusEl.innerHTML =
    '<div style="margin-top:12px;padding:14px;border-radius:14px;background:#effaf5;border:1px solid #c7ead9;color:#0f5132;text-align:left;font-size:13px;line-height:1.7;">' +
      '<div style="font-size:15px;font-weight:700;color:#065f46;margin-bottom:10px;">✓ Photo Validation Report</div>' +
      '<div>✅ Eyes Open</div>' +
      '<div>✅ Mouth Closed</div>' +
      '<div>✅ No Visible Teeth</div>' +
      '<div>✅ Head Position Detected</div>' +
      '<hr style="margin:10px 0;border:none;border-top:1px solid #d7eedd;">' +
      '<div style="color:#047857;">Please verify the <b>Crown</b> and <b>Chin</b> guide lines before creating your photo.</div>' +
    '</div>' +
    '<br><b>Auto detection completed.</b><br>Please verify the guide lines before creating your photo.';
  setCreateEnabled(true);
}

function getCurrentImage() {
  return bgRemovedImg || uploadedImg;
}

function getContainRect() {
  const img = getCurrentImage();
  const zw = zone.clientWidth;
  const zh = zone.clientHeight;
  const iw = img.naturalWidth || img.width;
  const ih = img.naturalHeight || img.height;
  const scale = Math.min(zw / iw, zh / ih);
  const dw = iw * scale;
  const dh = ih * scale;
  return { left: (zw - dw) / 2, top: (zh - dh) / 2, dw, dh, scale, iw, ih };
}

function lineTopPx(line) {
  return parseFloat(line.style.top || line.offsetTop || 0);
}

function setLineTop(line, y) {
  if (!getCurrentImage()) return;
  const rect = getContainRect();
  const clamped = Math.max(rect.top, Math.min(rect.top + rect.dh, y));
  line.style.top = clamped + 'px';
  setCreateEnabled(false);
  statusEl.textContent = 'Guide lines adjusted. Click Auto Detect again or create after validation.';
}

function imageYFromLine(line) {
  const rect = getContainRect();
  return (lineTopPx(line) - rect.top) / rect.scale;
}

function imageYToScreen(y) {
  const rect = getContainRect();
  return rect.top + y * rect.scale;
}

function initGuideLines() {
  if (!getCurrentImage()) return;
  const rect = getContainRect();
  crownLine.style.display = 'block';
  chinLine.style.display = 'block';
  crownLine.style.top = (rect.top + rect.dh * 0.18) + 'px';
  chinLine.style.top = (rect.top + rect.dh * 0.68) + 'px';
}

function clearPaymentState() {
  window.parent.localStorage.removeItem('usvisa_clean_photo');
  window.parent.localStorage.removeItem('usvisa_download_count');
  window.parent.localStorage.removeItem('usvisa_pending_clean_photo');
  window.parent.localStorage.removeItem('usvisa_protected_preview');
  if (window.parent.location.search.includes('paid=1')) {
    window.parent.history.replaceState({}, '', window.parent.location.pathname);
  }
}

function resetForNewUpload() {
  uploadedImg = null;
  bgRemovedImg = null;
  resultUrl = null;
  faceTiltAngle = 0;
  setCreateEnabled(false);
  setDownloadEnabled(false);
  resetValidationUI();
  createBtn.textContent = 'Create Photo';
  downloadBtn.style.display = 'none';
  downloadBtn.textContent = 'Unlock Download - $4.99';
  canvas.style.display = 'none';
  if (resultPanel) resultPanel.style.display = 'none';
  if (uploadTips) uploadTips.style.display = 'block';
  crownLine.style.display = 'none';
  chinLine.style.display = 'none';
  previewImg.style.display = 'none';
  previewImg.src = '';
  placeholder.style.display = 'flex';
}

fileInput.addEventListener('change', function(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  clearPaymentState();
  resetForNewUpload();
  uploadedFile = file;
  statusEl.textContent = 'Photo uploaded. Click Auto Detect.';

  const url = URL.createObjectURL(file);
  const img = new Image();

  img.onload = function() {
    uploadedImg = img;
    fileInput.classList.add('disabled-upload');
    previewImg.src = url;
    previewImg.style.display = 'block';
    previewImg.style.visibility = 'visible';
    previewImg.style.opacity = '1';
    placeholder.style.display = 'none';
    setTimeout(initGuideLines, 50);
  };

  img.onerror = function() {
    statusEl.textContent = 'Image preview failed. Please try another photo.';
  };

  img.src = url;
});

newPhotoBtn.addEventListener('click', function() {
  fileInput.classList.remove('disabled-upload');
  fileInput.value = '';
  fileInput.click();
});

[crownLine, chinLine].forEach(function(line) {
  line.addEventListener('mousedown', function(e) {
    e.preventDefault();
    draggingLine = line;
  });
  line.addEventListener('touchstart', function(e) {
    e.preventDefault();
    draggingLine = line;
  }, { passive: false });
});

window.addEventListener('mousemove', function(e) {
  if (!draggingLine || !getCurrentImage()) return;
  const rect = zone.getBoundingClientRect();
  setLineTop(draggingLine, e.clientY - rect.top);
});

window.addEventListener('mouseup', function() {
  draggingLine = null;
});

window.addEventListener('touchmove', function(e) {
  if (!draggingLine || !getCurrentImage()) return;
  e.preventDefault();
  const rect = zone.getBoundingClientRect();
  setLineTop(draggingLine, e.touches[0].clientY - rect.top);
}, { passive: false });

window.addEventListener('touchend', function() {
  draggingLine = null;
});

async function initFaceMesh() {
  if (faceMesh) return faceMesh;

  faceMesh = new FaceMesh({
    locateFile: function(file) {
      return 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/' + file;
    }
  });

  faceMesh.setOptions({
    maxNumFaces: 1,
    refineLandmarks: true,
    minDetectionConfidence: 0.5,
    minTrackingConfidence: 0.5
  });

  return faceMesh;
}

function eyeOpenRatio(lm, top, bottom, outer, inner) {
  const vertical = Math.abs(lm[top].y - lm[bottom].y);
  const horizontal = Math.abs(lm[outer].x - lm[inner].x);
  return horizontal ? vertical / horizontal : 0;
}

function validateDetectedPhoto(lm, iw, ih) {
  if (validationCard) {
    validationCard.style.display = 'block';
    validationCard.className = 'validation-card';
  }

  if (checkFace) checkFace.textContent = '✅ Face detected';

  const leftEyeRatio = eyeOpenRatio(lm, 159, 145, 33, 133);
  const rightEyeRatio = eyeOpenRatio(lm, 386, 374, 362, 263);
  const eyesClosed = leftEyeRatio < 0.16 || rightEyeRatio < 0.16;
  if (checkEyes) checkEyes.textContent = eyesClosed ? '❌ Eyes may be closed' : '✅ Eyes open';
  if (eyesClosed) {
    showValidationError('❌ Eyes may be closed.<br>Please upload another photo with both eyes open.');
    return false;
  }

  const mouthOpen = Math.abs(lm[13].y - lm[14].y);
  const faceHeightCheck = Math.abs(lm[152].y - lm[10].y);
  const mouthRatio = faceHeightCheck ? mouthOpen / faceHeightCheck : 0;
  const mouthProblem = mouthRatio > 0.055;
  if (checkMouth) checkMouth.textContent = mouthProblem ? '❌ Mouth may be open or smiling' : '✅ Mouth closed';
  if (mouthProblem) {
    showValidationError('❌ Mouth should be closed with no visible teeth.<br>Please upload another photo.');
    return false;
  }

  if (checkGlasses) checkGlasses.textContent = '✅ Glasses check passed';

  const foreheadY = lm[10].y * ih;
  const chinY = lm[152].y * ih;
  const faceHeight = Math.max(1, chinY - foreheadY);
  const estimatedCrownY = Math.max(0, foreheadY - faceHeight * 0.38);
  const crownToChinRatio = (chinY - estimatedCrownY) / ih;
  const bottomSpaceRatio = 1 - lm[152].y;

  const alreadyCropped = crownToChinRatio > 0.60 || bottomSpaceRatio < 0.18;
  if (checkPosition) {
    checkPosition.textContent = alreadyCropped
      ? '❌ Photo appears already cropped'
      : '✅ Head position detected';
  }
  if (alreadyCropped) {
    showValidationError(
      '❌ This looks like an already-cropped ID/passport photo.<br>' +
      'Please upload the original photo taken from farther away, with shoulders visible.'
    );
    return false;
  }

  return { estimatedCrownY, detectedChinY: chinY };
}

detectBtn.addEventListener('click', async function(e) {
  e.preventDefault();
  const img = getCurrentImage();

  if (!img) {
    statusEl.textContent = 'Please upload a photo first.';
    setCreateEnabled(false);
    return;
  }

  setCreateEnabled(false);
  statusEl.textContent = 'Detecting face...';

  try {
    const fm = await initFaceMesh();
    let detected = null;
    fm.onResults(function(results) { detected = results; });

    const iw = img.naturalWidth || img.width;
    const ih = img.naturalHeight || img.height;
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = iw;
    tempCanvas.height = ih;
    tempCanvas.getContext('2d').drawImage(img, 0, 0);

    await fm.send({ image: tempCanvas });

    let wait = 0;
    while (!detected && wait < 3000) {
      await new Promise(function(resolve) { setTimeout(resolve, 100); });
      wait += 100;
    }

    if (!detected || !detected.multiFaceLandmarks || !detected.multiFaceLandmarks.length) {
      showValidationError('❌ Face could not be detected.<br>Please upload another photo.');
      return;
    }

    if (detected.multiFaceLandmarks.length > 1) {
      showValidationError('❌ More than one face detected.<br>Please upload a photo with only one person.');
      return;
    }

    const lm = detected.multiFaceLandmarks[0];
    const leftEye = lm[33];
    const rightEye = lm[263];
    faceTiltAngle = Math.atan2(rightEye.y - leftEye.y, rightEye.x - leftEye.x);

    const validation = validateDetectedPhoto(lm, iw, ih);
    if (!validation) return;

    crownLine.style.display = 'block';
    chinLine.style.display = 'block';
    crownLine.style.top = imageYToScreen(validation.estimatedCrownY) + 'px';
    chinLine.style.top = imageYToScreen(validation.detectedChinY) + 'px';

    showValidationReady();
  } catch (err) {
    console.error(err);
    showValidationError('❌ Auto detect failed.<br>Please try another photo.');
  }
});

function enhanceCanvas(ctx, width, height) {
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;
  const contrast = 1.08;
  const brightness = 4;

  for (let i = 0; i < data.length; i += 4) {
    if (data[i] > 245 && data[i + 1] > 245 && data[i + 2] > 245) continue;
    data[i] = Math.min(255, Math.max(0, (data[i] - 128) * contrast + 128 + brightness));
    data[i + 1] = Math.min(255, Math.max(0, (data[i + 1] - 128) * contrast + 128 + brightness));
    data[i + 2] = Math.min(255, Math.max(0, (data[i + 2] - 128) * contrast + 128 + brightness));
  }

  ctx.putImageData(imageData, 0, 0);
}

function applyPreviewProtection(ctx, width, height) {
  const original = ctx.getImageData(0, 0, width, height);
  const blurX = width * 0.28;
  const blurY = height * 0.28;
  const blurW = width * 0.44;
  const blurH = height * 0.30;
  const tempCanvas = document.createElement('canvas');
  tempCanvas.width = width;
  tempCanvas.height = height;
  const tempCtx = tempCanvas.getContext('2d');
  tempCtx.putImageData(original, 0, 0);

  ctx.save();
  ctx.filter = 'blur(10px)';
  ctx.drawImage(tempCanvas, blurX, blurY, blurW, blurH, blurX, blurY, blurW, blurH);
  ctx.restore();

  ctx.save();
  ctx.globalAlpha = 0.18;
  ctx.fillStyle = '#1e3a8a';
  ctx.font = 'bold 22px Arial';
  ctx.rotate(-0.45);
  for (let y = -height; y < height * 2; y += 90) {
    for (let x = -width; x < width * 2; x += 180) {
      ctx.fillText('USVISAPHOTO PREVIEW', x, y);
    }
  }
  ctx.restore();

  ctx.save();
  ctx.globalAlpha = 0.85;
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(width * 0.12, height * 0.72, width * 0.76, 52);
  ctx.globalAlpha = 1;
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 18px Arial';
  ctx.textAlign = 'center';
  ctx.fillText('Unlock high-quality download after payment', width / 2, height * 0.72 + 33);
  ctx.restore();
}

async function removeBackgroundWithPhotoRoom() {
  if (!uploadedFile) throw new Error('No uploaded file');
  statusEl.textContent = 'Processing background...';

  const formData = new FormData();
  formData.append('image', uploadedFile);

  const response = await fetch('/api/remove-background', { method: 'POST', body: formData });
  if (!response.ok) throw new Error(await response.text() || 'Background removal failed');

  const blob = await response.blob();
  const url = URL.createObjectURL(blob);

  return await new Promise(function(resolve, reject) {
    const img = new Image();
    img.onload = function() { resolve(img); };
    img.onerror = reject;
    img.src = url;
  });
}

function drawFinalPhoto(sourceImg) {
  const crownY = imageYFromLine(crownLine);
  const chinY = imageYFromLine(chinLine);
  const currentHeadPx = Math.max(1, chinY - crownY);
  const scale = TARGET_HEAD_PX / currentHeadPx;
  const outputCrownY = TOP_MARGIN_PX;
  const outputChinY = outputCrownY + TARGET_HEAD_PX;
  const centerX = (sourceImg.naturalWidth || sourceImg.width) / 2;
  const sourceCrownToCenter = centerX;

  canvas.width = TARGET;
  canvas.height = TARGET;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, TARGET, TARGET);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, TARGET, TARGET);

  ctx.save();
  ctx.translate(TARGET / 2, outputCrownY);
  ctx.rotate(-faceTiltAngle);
  ctx.scale(scale, scale);
  ctx.drawImage(sourceImg, -centerX, -crownY);
  ctx.restore();

  enhanceCanvas(ctx, TARGET, TARGET);
  return canvas.toDataURL('image/jpeg', 0.95);
}

createBtn.addEventListener('click', async function(e) {
  e.preventDefault();

  if (!uploadedImg) {
    statusEl.textContent = 'Please upload a photo first.';
    return;
  }

  if (!photoValidationPassed) {
    statusEl.textContent = 'Please click Auto Detect and pass validation before creating your photo.';
    setCreateEnabled(false);
    return;
  }

  try {
    setCreateEnabled(false);
    createBtn.textContent = 'Creating...';
    statusEl.textContent = 'Creating your photo...';

    bgRemovedImg = await removeBackgroundWithPhotoRoom();
    const cleanUrl = drawFinalPhoto(bgRemovedImg);
    resultUrl = cleanUrl;
    window.parent.localStorage.setItem('usvisa_clean_photo', cleanUrl);
    window.parent.localStorage.setItem('usvisa_download_count', '0');

    const protectedCanvas = document.createElement('canvas');
    protectedCanvas.width = TARGET;
    protectedCanvas.height = TARGET;
    const pctx = protectedCanvas.getContext('2d');
    const finalPreview = new Image();
    await new Promise(function(resolve, reject) {
      finalPreview.onload = resolve;
      finalPreview.onerror = reject;
      finalPreview.src = cleanUrl;
    });
    pctx.drawImage(finalPreview, 0, 0);
    applyPreviewProtection(pctx, TARGET, TARGET);
    window.parent.localStorage.setItem('usvisa_protected_preview', protectedCanvas.toDataURL('image/jpeg', 0.9));

    ctx.clearRect(0, 0, TARGET, TARGET);
    ctx.drawImage(protectedCanvas, 0, 0);
    canvas.style.display = 'block';
    if (resultPanel) resultPanel.style.display = 'block';
    if (uploadTips) uploadTips.style.display = 'none';
    downloadBtn.style.display = 'inline-flex';
    downloadBtn.textContent = window.parent.location.search.includes('paid=1')
      ? 'Download Photo'
      : 'Unlock Download - $4.99';
    setDownloadEnabled(true);
    statusEl.textContent = 'Preview created. Unlock download to receive the clean photo.';
  } catch (err) {
    console.error(err);
    statusEl.textContent = 'Photo creation failed. Please try again.';
    setCreateEnabled(true);
  } finally {
    createBtn.textContent = 'Create Photo';
  }
});

downloadBtn.addEventListener('click', async function() {
  if (!resultUrl) {
    statusEl.textContent = 'Please create your photo first.';
    return;
  }

  const isPaid = window.parent.location.search.includes('paid=1');

  if (isPaid) {
    const count = Number(window.parent.localStorage.getItem('usvisa_download_count') || downloadBtn.dataset.downloadCount || '0');
    if (count >= 5) {
      statusEl.textContent = 'Download limit reached. Please start a new order if needed.';
      setDownloadEnabled(false);
      downloadBtn.textContent = 'Download limit reached';
      return;
    }

    const a = document.createElement('a');
    a.href = resultUrl;
    a.download = 'USVisaPhoto_Embassy_Ready.jpg';
    a.click();

    const nextCount = count + 1;
    downloadBtn.dataset.downloadCount = String(nextCount);
    window.parent.localStorage.setItem('usvisa_download_count', String(nextCount));
    statusEl.textContent = 'Download complete. Remaining downloads: ' + (5 - nextCount);
    return;
  }

  setDownloadEnabled(false);
  downloadBtn.textContent = 'Opening checkout...';

  try {
    const response = await fetch('/api/create-paypal-order', { method: 'POST' });
    const data = await response.json();
    if (!data.url) throw new Error('No checkout URL');
    window.parent.location.href = data.url;
  } catch (error) {
    console.error(error);
    statusEl.textContent = 'Payment page failed to open. Please try again.';
    downloadBtn.textContent = 'Unlock Download - $4.99';
    setDownloadEnabled(true);
  }
});

function restorePaidDownloadIfAvailable() {
  const clean = window.parent.localStorage.getItem('usvisa_clean_photo');
  const protectedPreview = window.parent.localStorage.getItem('usvisa_protected_preview');
  if (!clean && !protectedPreview) return;

  const img = new Image();
  img.onload = function() {
    canvas.width = TARGET;
    canvas.height = TARGET;
    ctx.clearRect(0, 0, TARGET, TARGET);
    ctx.drawImage(img, 0, 0);
    canvas.style.display = 'block';
    if (resultPanel) resultPanel.style.display = 'block';
    if (uploadTips) uploadTips.style.display = 'none';
    downloadBtn.style.display = 'inline-flex';

    resultUrl = clean || protectedPreview;
    if (window.parent.location.search.includes('paid=1')) {
      downloadBtn.textContent = 'Download Photo';
      statusEl.textContent = 'Payment confirmed. You can download your clean photo.';
    } else {
      downloadBtn.textContent = 'Unlock Download - $4.99';
      statusEl.textContent = 'Preview restored. Unlock download to receive the clean photo.';
    }
    setDownloadEnabled(true);
  };
  img.src = window.parent.location.search.includes('paid=1') && clean ? clean : protectedPreview;
}

setCreateEnabled(false);
setDownloadEnabled(false);
restorePaidDownloadIfAvailable();
`;
